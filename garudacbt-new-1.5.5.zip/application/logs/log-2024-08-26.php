<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-26 16:28:03 --> Severity: error --> Exception: Too few arguments to function Dashboard::getJadwalKbm(), 0 passed in C:\laragon\www\ambk\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\ambk\application\controllers\Dashboard.php 462
ERROR - 2024-08-26 16:28:16 --> Severity: error --> Exception: Too few arguments to function Dashboard::getJadwalKbm(), 0 passed in C:\laragon\www\ambk\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\ambk\application\controllers\Dashboard.php 462
ERROR - 2024-08-26 16:28:22 --> Query error: Expression #4 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'elearning.kelas_jadwal_mapel.id_kelas' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `id_tp`, `id_smt`, MAX(id_hari) as id_hari, `id_kelas`, MAX(jam_ke) as jam_ke
FROM `kelas_jadwal_mapel`
WHERE id_tp =  5
AND id_smt =  1
AND id_kelas IS NULL
GROUP BY `jam_ke`
ERROR - 2024-08-26 16:28:24 --> Severity: error --> Exception: Too few arguments to function Dashboard::getJadwalKbm(), 0 passed in C:\laragon\www\ambk\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\ambk\application\controllers\Dashboard.php 462
