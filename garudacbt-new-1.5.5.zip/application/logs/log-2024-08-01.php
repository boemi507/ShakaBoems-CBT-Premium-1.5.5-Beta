<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-01 13:03:35 --> Severity: Notice --> Undefined offset: 160 C:\laragon\www\ambk\application\views\kelas\jadwal\data.php 91
ERROR - 2024-08-01 13:04:21 --> Severity: Notice --> Undefined variable: siswas C:\laragon\www\ambk\application\views\kelas\materijadwal\data.php 378
ERROR - 2024-08-01 13:04:21 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\materijadwal\data.php 378
ERROR - 2024-08-01 14:04:29 --> Severity: error --> Exception: syntax error, unexpected '$dates' (T_VARIABLE) C:\laragon\www\ambk\application\controllers\Kelasabsensibulanan.php 161
