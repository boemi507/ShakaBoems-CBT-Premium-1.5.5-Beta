<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-10 14:54:54 --> Severity: Notice --> A non well formed numeric value encountered C:\laragon\www\ambk\application\controllers\Elearning.php 387
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: idKls C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-10 15:00:21 --> Severity: Notice --> Undefined variable: ist C:\laragon\www\ambk\application\controllers\Elearning.php 464
ERROR - 2024-08-10 15:06:19 --> Severity: Notice --> Undefined variable: ist C:\laragon\www\ambk\application\controllers\Elearning.php 462
ERROR - 2024-08-10 15:08:05 --> Severity: Notice --> Undefined variable: jamke C:\laragon\www\ambk\application\controllers\Elearning.php 418
ERROR - 2024-08-10 15:08:05 --> Severity: Notice --> Undefined index: method C:\laragon\www\ambk\application\controllers\Elearning.php 423
