<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-13 15:13:24 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 118
ERROR - 2024-08-13 15:13:24 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 44
ERROR - 2024-08-13 15:13:24 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 140
ERROR - 2024-08-13 15:13:24 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 140
ERROR - 2024-08-13 15:13:24 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 149
ERROR - 2024-08-13 15:13:24 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 168
ERROR - 2024-08-13 15:13:24 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 178
ERROR - 2024-08-13 15:13:58 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 118
ERROR - 2024-08-13 15:13:58 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 44
ERROR - 2024-08-13 15:13:58 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 140
ERROR - 2024-08-13 15:13:58 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 140
ERROR - 2024-08-13 15:13:58 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 149
ERROR - 2024-08-13 15:13:58 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 168
ERROR - 2024-08-13 15:13:58 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 178
ERROR - 2024-08-13 15:14:12 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 44
ERROR - 2024-08-13 15:14:12 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 140
ERROR - 2024-08-13 15:14:12 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 140
ERROR - 2024-08-13 15:14:12 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 149
ERROR - 2024-08-13 15:14:12 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 168
ERROR - 2024-08-13 15:14:12 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 178
ERROR - 2024-08-13 15:21:10 --> Severity: Notice --> Undefined property: stdClass::$dari C:\laragon\www\ambk\application\controllers\Elearning.php 111
ERROR - 2024-08-13 15:21:10 --> Severity: Notice --> Undefined property: stdClass::$libur C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 44
ERROR - 2024-08-13 15:21:10 --> Severity: Notice --> Undefined property: stdClass::$libur C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 140
ERROR - 2024-08-13 15:21:10 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 140
ERROR - 2024-08-13 15:23:48 --> Severity: Notice --> Undefined property: stdClass::$dari C:\laragon\www\ambk\application\controllers\Elearning.php 111
ERROR - 2024-08-13 15:23:48 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 140
ERROR - 2024-08-13 15:26:48 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 140
ERROR - 2024-08-13 15:35:34 --> Severity: Notice --> Trying to get property 'convert' of non-object C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 38
