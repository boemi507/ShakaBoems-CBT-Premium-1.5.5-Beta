<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-21 09:22:18 --> Severity: Warning --> Attempt to read property "istirahat" on null C:\laragon\www\ambk\application\controllers\Dashboard.php 466
ERROR - 2024-05-21 09:22:18 --> Severity: 8192 --> unserialize(): Passing null to parameter #1 ($data) of type string is deprecated C:\laragon\www\ambk\application\controllers\Dashboard.php 466
ERROR - 2024-05-21 10:07:00 --> Severity: error --> Exception: Undefined constant "soal" C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 31
ERROR - 2024-05-21 10:13:36 --> Severity: Warning --> Attempt to read property "jawaban_siswa" on array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 33
ERROR - 2024-05-21 10:16:05 --> Severity: Warning --> Undefined property: stdClass::$links_benar C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 35
ERROR - 2024-05-21 10:16:53 --> Severity: Warning --> Undefined property: stdClass::$jawaban_benar C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 35
ERROR - 2024-05-21 10:38:24 --> Severity: Warning --> Undefined property: stdClass::$jawaban_benar C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 35
ERROR - 2024-05-21 10:38:55 --> Severity: Warning --> Undefined property: stdClass::$links_benar C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 35
ERROR - 2024-05-21 10:39:54 --> Severity: Warning --> Undefined property: stdClass::$links_benar C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 35
ERROR - 2024-05-21 10:40:28 --> Severity: Warning --> Undefined property: stdClass::$links_benar C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 35
ERROR - 2024-05-21 11:53:03 --> Severity: error --> Exception: printf(): Argument #1 ($format) must be of type string, array given C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 42
ERROR - 2024-05-21 13:35:18 --> Severity: Warning --> Undefined array key 3 C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 33
ERROR - 2024-05-21 13:35:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 33
ERROR - 2024-05-21 13:35:18 --> Severity: Warning --> Undefined array key 3 C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 37
ERROR - 2024-05-21 13:35:18 --> Severity: Warning --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 37
ERROR - 2024-05-21 13:35:18 --> Severity: Warning --> Attempt to read property "jawaban_benar" on null C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 37
ERROR - 2024-05-21 13:35:18 --> Severity: Warning --> Attempt to read property "links" on null C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 37
ERROR - 2024-05-21 13:38:05 --> Severity: Warning --> Undefined array key 3 C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 33
ERROR - 2024-05-21 13:38:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 33
ERROR - 2024-05-21 13:38:05 --> Severity: Warning --> Undefined array key 3 C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 37
ERROR - 2024-05-21 13:38:05 --> Severity: Warning --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 37
ERROR - 2024-05-21 13:38:05 --> Severity: Warning --> Attempt to read property "jawaban_benar" on null C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 37
ERROR - 2024-05-21 13:38:05 --> Severity: Warning --> Attempt to read property "links" on null C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 37
ERROR - 2024-05-21 15:04:33 --> Severity: Warning --> Attempt to read property "istirahat" on null C:\laragon\www\ambk\application\controllers\Dashboard.php 466
ERROR - 2024-05-21 15:04:33 --> Severity: 8192 --> unserialize(): Passing null to parameter #1 ($data) of type string is deprecated C:\laragon\www\ambk\application\controllers\Dashboard.php 466
ERROR - 2024-05-21 15:11:40 --> Severity: Warning --> Attempt to read property "jawaban" on bool C:\laragon\www\ambk\application\controllers\Cbtnilai.php 588
ERROR - 2024-05-21 15:18:47 --> Severity: Warning --> Attempt to read property "links" on bool C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 33
ERROR - 2024-05-21 15:20:30 --> Severity: error --> Exception: Attempt to assign property "links" on bool C:\laragon\www\ambk\application\controllers\Cbtnilai.php 603
ERROR - 2024-05-21 15:24:55 --> Severity: Warning --> Attempt to read property "links" on bool C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 33
ERROR - 2024-05-21 15:27:09 --> Severity: error --> Exception: Attempt to assign property "links" on array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 607
ERROR - 2024-05-21 15:27:19 --> Severity: error --> Exception: Attempt to assign property "links" on bool C:\laragon\www\ambk\application\controllers\Cbtnilai.php 607
ERROR - 2024-05-21 15:28:35 --> Severity: error --> Exception: Attempt to assign property "links" on array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 607
ERROR - 2024-05-21 15:28:36 --> Severity: error --> Exception: Attempt to assign property "links" on array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 607
ERROR - 2024-05-21 15:29:19 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 606
ERROR - 2024-05-21 15:31:31 --> Severity: error --> Exception: Attempt to assign property "links" on array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 607
ERROR - 2024-05-21 15:31:54 --> Severity: error --> Exception: Attempt to assign property "links" on string C:\laragon\www\ambk\application\controllers\Cbtnilai.php 607
ERROR - 2024-05-21 15:32:10 --> Severity: error --> Exception: Attempt to assign property "links" on array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 607
ERROR - 2024-05-21 15:33:16 --> Severity: error --> Exception: Attempt to assign property "links" on bool C:\laragon\www\ambk\application\controllers\Cbtnilai.php 607
ERROR - 2024-05-21 15:33:17 --> Severity: error --> Exception: Attempt to assign property "links" on bool C:\laragon\www\ambk\application\controllers\Cbtnilai.php 607
ERROR - 2024-05-21 15:33:29 --> Severity: error --> Exception: Attempt to assign property "links" on bool C:\laragon\www\ambk\application\controllers\Cbtnilai.php 607
ERROR - 2024-05-21 15:33:30 --> Severity: error --> Exception: Attempt to assign property "links" on bool C:\laragon\www\ambk\application\controllers\Cbtnilai.php 607
ERROR - 2024-05-21 15:34:10 --> Severity: Warning --> Attempt to read property "links" on bool C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 33
ERROR - 2024-05-21 15:37:47 --> Severity: Warning --> Attempt to read property "links" on array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 33
ERROR - 2024-05-21 15:39:29 --> Severity: error --> Exception: Attempt to assign property "links" on bool C:\laragon\www\ambk\application\controllers\Cbtnilai.php 606
ERROR - 2024-05-21 15:40:24 --> Severity: Warning --> Undefined array key "links" C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 33
ERROR - 2024-05-21 15:40:45 --> Severity: error --> Exception: Attempt to assign property "links" on array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 607
ERROR - 2024-05-21 15:41:21 --> Severity: error --> Exception: Attempt to assign property "links" on array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 607
ERROR - 2024-05-21 15:41:22 --> Severity: error --> Exception: Attempt to assign property "links" on array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 607
ERROR - 2024-05-21 15:42:10 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 33
