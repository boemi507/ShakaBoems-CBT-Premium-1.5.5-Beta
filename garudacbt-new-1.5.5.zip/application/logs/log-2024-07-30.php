<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-07-30 12:03:36 --> Severity: Notice --> Undefined offset: 1 C:\laragon\www\ambk\application\controllers\Cbtactivate.php 151
ERROR - 2024-07-30 12:03:36 --> Severity: Notice --> Undefined offset: 1 C:\laragon\www\ambk\application\controllers\Cbtactivate.php 151
ERROR - 2024-07-30 12:03:36 --> Severity: Notice --> Undefined offset: 1 C:\laragon\www\ambk\application\controllers\Cbtactivate.php 151
ERROR - 2024-07-30 12:03:36 --> Severity: Notice --> Undefined offset: 1 C:\laragon\www\ambk\application\controllers\Cbtactivate.php 151
ERROR - 2024-07-30 12:03:36 --> Severity: Notice --> Undefined offset: 1 C:\laragon\www\ambk\application\controllers\Cbtactivate.php 151
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:33:19 --> Severity: Notice --> Undefined property: stdClass::$nis C:\laragon\www\ambk\application\controllers\Cbtactivate.php 199
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 12:38:12 --> Severity: Notice --> Undefined property: stdClass::$id C:\laragon\www\ambk\application\controllers\Cbtactivate.php 259
ERROR - 2024-07-30 13:49:29 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Dashboard.php 466
ERROR - 2024-07-30 13:51:00 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Dashboard.php 466
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'id_bank' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 37
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 74
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 78
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 82
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 86
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 90
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 101
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'bank_kelas' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 109
ERROR - 2024-07-30 14:45:34 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 114
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'bank_kode' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 132
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 135
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'nama_guru' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 139
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 206
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 220
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'bobot_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 222
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'bobot_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 225
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 240
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 252
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 257
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 366
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'bobot_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 368
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'bobot_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 371
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 386
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 398
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 403
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 513
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'bobot_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 515
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'bobot_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 518
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 533
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 545
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 550
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 650
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'bobot_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 652
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'bobot_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 655
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 670
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 682
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 687
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 782
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'bobot_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 784
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'bobot_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 787
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 802
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 813
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 818
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1319
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1320
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1321
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1322
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1323
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'bank_kode' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1673
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1673
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'bank_level' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1673
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1677
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'bank_level' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1677
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'id_bank' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 37
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 74
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 78
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 82
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 86
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 90
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:34 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 101
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_kelas' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 109
ERROR - 2024-07-30 14:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 114
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_kode' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 132
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 135
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'nama_guru' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 139
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 206
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 220
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 222
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 225
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 240
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 252
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 257
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 366
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 368
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 371
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 386
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 398
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 403
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 513
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 515
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 518
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 533
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 545
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 550
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 650
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 652
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 655
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 670
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 682
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 687
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 782
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 784
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 787
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 802
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 813
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 818
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1319
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1320
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1321
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1322
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1323
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_kode' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1673
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1673
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_level' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1673
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1677
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_level' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1677
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'id_bank' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 37
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 74
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 78
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 82
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 86
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 90
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 101
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_kelas' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 109
ERROR - 2024-07-30 14:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 114
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_kode' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 132
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 135
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'nama_guru' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 139
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 206
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 220
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 222
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 225
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 240
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 252
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 257
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 366
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 368
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 371
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 386
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 398
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 403
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 513
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 515
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 518
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 533
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 545
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 550
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 650
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 652
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 655
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 670
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 682
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 687
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 782
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 784
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 787
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 802
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 813
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 818
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1319
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1320
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1321
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1322
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1323
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_kode' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1673
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1673
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_level' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1673
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1677
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_level' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1677
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'id_bank' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 37
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 74
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 78
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 82
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 86
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 90
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 101
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_kelas' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 109
ERROR - 2024-07-30 14:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 114
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_kode' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 132
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 135
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'nama_guru' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 139
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 206
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 220
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 222
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 225
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 240
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 252
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 257
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 366
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 368
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 371
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 386
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 398
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 403
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 513
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 515
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 518
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 533
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 545
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 550
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 650
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 652
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 655
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 670
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 682
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 687
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 782
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 784
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 787
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 802
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 813
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 818
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1319
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1320
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1321
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1322
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1323
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_kode' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1673
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1673
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_level' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1673
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1677
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_level' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1677
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'id_bank' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 37
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 74
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 78
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 82
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 86
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 90
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 93
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 101
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_kelas' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 109
ERROR - 2024-07-30 14:45:35 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 114
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_kode' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 132
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 135
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'nama_guru' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 139
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 206
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 220
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 222
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 225
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 240
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 252
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 257
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 366
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 368
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 371
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 386
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 398
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 403
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 513
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 515
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 518
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 533
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 545
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 550
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 650
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 652
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 655
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 670
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 682
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 687
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 782
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 784
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bobot_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 787
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 802
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 813
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'digunakan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 818
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_pg' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1319
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_kompleks' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1320
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_jodohkan' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1321
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_isian' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1322
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'tampil_esai' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1323
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_kode' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1673
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1673
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_level' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1673
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'nama_mapel' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1677
ERROR - 2024-07-30 14:45:35 --> Severity: Notice --> Trying to get property 'bank_level' of non-object C:\laragon\www\ambk\application\views\cbt\banksoal\detail.php 1677
