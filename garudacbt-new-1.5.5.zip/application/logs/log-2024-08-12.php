<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-12 14:21:16 --> Severity: error --> Exception: syntax error, unexpected '}' C:\laragon\www\ambk\application\controllers\Elearning.php 261
