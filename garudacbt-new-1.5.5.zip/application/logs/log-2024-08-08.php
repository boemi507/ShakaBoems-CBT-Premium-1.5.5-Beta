<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-08 10:19:40 --> Severity: Notice --> Undefined variable: jadwal_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-08 10:19:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 649
ERROR - 2024-08-08 10:20:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 649
ERROR - 2024-08-08 10:21:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 650
ERROR - 2024-08-08 10:21:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 649
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'dari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'sampai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'dari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'sampai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'dari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'sampai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'dari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'sampai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'dari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'sampai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'dari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'sampai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'dari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'sampai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'dari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'sampai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'dari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'sampai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'dari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'sampai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'dari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'sampai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'dari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'sampai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'dari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'sampai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'dari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'sampai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'dari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'sampai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'dari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Notice --> Trying to get property 'sampai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 10:23:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 649
ERROR - 2024-08-08 10:23:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 649
ERROR - 2024-08-08 10:25:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 651
ERROR - 2024-08-08 10:25:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 651
ERROR - 2024-08-08 10:26:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 651
ERROR - 2024-08-08 10:35:51 --> Severity: Notice --> Undefined variable: jadwal_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-08 10:38:34 --> Severity: Notice --> Undefined variable: jadwal_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-08 10:38:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 651
ERROR - 2024-08-08 10:44:05 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 389
ERROR - 2024-08-08 10:44:05 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 390
ERROR - 2024-08-08 10:44:10 --> Severity: Notice --> Undefined variable: jadwal_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-08 10:44:13 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 389
ERROR - 2024-08-08 10:44:13 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 390
ERROR - 2024-08-08 10:45:19 --> Severity: Notice --> Undefined variable: jadwal_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-08 10:47:51 --> Severity: Notice --> Undefined variable: jadwal_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-08 10:54:31 --> Severity: Notice --> Undefined variable: jadwal_kbm C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 10:54:31 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 10:54:31 --> Severity: Notice --> Undefined variable: jadwal_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-08 10:55:15 --> Severity: Notice --> Undefined variable: jadwal_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-08 10:55:28 --> Severity: Notice --> Undefined variable: jadwal_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-08 10:56:03 --> Severity: Notice --> Undefined variable: jadwal_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-08 10:57:27 --> Severity: Notice --> Undefined variable: jadwal_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-08 10:57:47 --> Severity: Notice --> Undefined variable: jadwal_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-08 10:58:49 --> Severity: Notice --> Undefined variable: jadwal_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 382
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\controllers\Elearning.php 387
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 392
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 393
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 419
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'detail' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 457
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'arr_jam' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 459
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 463
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 464
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 484
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Illegal offset type C:\laragon\www\ambk\application\controllers\Elearning.php 485
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 382
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\controllers\Elearning.php 387
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 392
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 393
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 419
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'detail' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 457
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'arr_jam' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 459
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 463
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 464
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 484
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Illegal offset type C:\laragon\www\ambk\application\controllers\Elearning.php 485
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 382
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\controllers\Elearning.php 387
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 392
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 393
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 419
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'detail' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 457
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'arr_jam' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 459
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 463
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 464
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 484
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Illegal offset type C:\laragon\www\ambk\application\controllers\Elearning.php 485
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 382
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\controllers\Elearning.php 387
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 392
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 393
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 419
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'detail' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 457
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'arr_jam' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 459
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 463
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 464
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 484
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Illegal offset type C:\laragon\www\ambk\application\controllers\Elearning.php 485
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 382
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\controllers\Elearning.php 387
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 392
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 393
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 419
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'detail' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 457
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'arr_jam' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 459
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 463
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 464
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 484
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> Illegal offset type C:\laragon\www\ambk\application\controllers\Elearning.php 485
ERROR - 2024-08-08 10:58:53 --> Severity: Notice --> Undefined index: span C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 121
ERROR - 2024-08-08 10:58:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 651
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 382
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\controllers\Elearning.php 387
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 392
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 393
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 419
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'detail' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 457
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'arr_jam' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 459
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 463
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 464
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 484
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Illegal offset type C:\laragon\www\ambk\application\controllers\Elearning.php 485
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 382
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\controllers\Elearning.php 387
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 392
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 393
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 419
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'detail' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 457
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'arr_jam' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 459
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 463
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 464
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 484
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Illegal offset type C:\laragon\www\ambk\application\controllers\Elearning.php 485
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 382
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\controllers\Elearning.php 387
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 392
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 393
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 419
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'detail' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 457
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'arr_jam' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 459
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 463
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 464
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 484
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Illegal offset type C:\laragon\www\ambk\application\controllers\Elearning.php 485
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 382
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\controllers\Elearning.php 387
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 392
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 393
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 419
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'detail' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 457
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'arr_jam' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 459
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 463
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 464
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 484
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Illegal offset type C:\laragon\www\ambk\application\controllers\Elearning.php 485
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 382
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\controllers\Elearning.php 387
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 392
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 393
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 419
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 397
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'detail' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 457
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'arr_jam' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 459
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 461
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 463
ERROR - 2024-08-08 11:00:19 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 464
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Attempt to assign property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 484
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> Illegal offset type C:\laragon\www\ambk\application\controllers\Elearning.php 485
ERROR - 2024-08-08 11:00:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 651
ERROR - 2024-08-08 11:10:46 --> Severity: Notice --> Undefined variable: times C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 117
ERROR - 2024-08-08 11:10:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 117
ERROR - 2024-08-08 11:10:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 651
ERROR - 2024-08-08 11:13:02 --> Severity: Notice --> Undefined variable: times C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 117
ERROR - 2024-08-08 11:13:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 117
ERROR - 2024-08-08 11:13:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 651
ERROR - 2024-08-08 11:14:06 --> Severity: Notice --> Undefined variable: times C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 117
ERROR - 2024-08-08 11:14:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 117
ERROR - 2024-08-08 11:14:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 651
ERROR - 2024-08-08 11:19:20 --> Severity: Notice --> Undefined variable: times C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 118
ERROR - 2024-08-08 11:19:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 118
ERROR - 2024-08-08 11:19:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:19:40 --> Severity: Notice --> Undefined variable: times C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 118
ERROR - 2024-08-08 11:19:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 118
ERROR - 2024-08-08 11:19:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:29:19 --> Severity: Notice --> Undefined variable: times C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 118
ERROR - 2024-08-08 11:29:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 118
ERROR - 2024-08-08 11:29:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:30:02 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 356
ERROR - 2024-08-08 11:30:02 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:30:02 --> Severity: Notice --> Undefined variable: times C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 118
ERROR - 2024-08-08 11:30:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 118
ERROR - 2024-08-08 11:30:02 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:30:02 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:30:02 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:30:02 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:30:02 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:30:53 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 356
ERROR - 2024-08-08 11:30:54 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:30:54 --> Severity: Notice --> Undefined variable: times C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 118
ERROR - 2024-08-08 11:30:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 118
ERROR - 2024-08-08 11:30:54 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:30:54 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:30:54 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:30:54 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:30:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:31:06 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 78
ERROR - 2024-08-08 11:31:06 --> Severity: Warning --> Creating default object from empty value C:\laragon\www\ambk\application\controllers\Elearning.php 79
ERROR - 2024-08-08 11:31:06 --> Severity: Notice --> Undefined property: stdClass::$libur C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:31:06 --> Severity: Notice --> Undefined variable: test_kbm C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-08 11:31:06 --> Severity: Notice --> Undefined property: stdClass::$kbm_jam_mulai C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:31:06 --> Severity: Notice --> Undefined property: stdClass::$kbm_jam_pel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:31:06 --> Severity: Notice --> Undefined property: stdClass::$kbm_jml_mapel_hari C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:31:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:32:33 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 78
ERROR - 2024-08-08 11:32:33 --> Severity: Warning --> Creating default object from empty value C:\laragon\www\ambk\application\controllers\Elearning.php 79
ERROR - 2024-08-08 11:32:33 --> Severity: Notice --> Undefined property: stdClass::$libur C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:32:33 --> Severity: Notice --> Undefined variable: test_kbm C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-08 11:32:33 --> Severity: Notice --> Undefined property: stdClass::$kbm_jam_mulai C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:32:33 --> Severity: Notice --> Undefined property: stdClass::$kbm_jam_pel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:32:33 --> Severity: Notice --> Undefined property: stdClass::$kbm_jml_mapel_hari C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:32:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:32:57 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\controllers\Elearning.php 78
ERROR - 2024-08-08 11:32:57 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 78
ERROR - 2024-08-08 11:32:57 --> Severity: Warning --> Creating default object from empty value C:\laragon\www\ambk\application\controllers\Elearning.php 79
ERROR - 2024-08-08 11:32:57 --> Severity: Notice --> Undefined property: stdClass::$libur C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:32:57 --> Severity: Notice --> Undefined variable: test_kbm C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-08 11:32:57 --> Severity: Notice --> Undefined property: stdClass::$kbm_jam_mulai C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:32:57 --> Severity: Notice --> Undefined property: stdClass::$kbm_jam_pel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:32:57 --> Severity: Notice --> Undefined property: stdClass::$kbm_jml_mapel_hari C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:32:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:33:49 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 78
ERROR - 2024-08-08 11:33:49 --> Severity: Warning --> Creating default object from empty value C:\laragon\www\ambk\application\controllers\Elearning.php 79
ERROR - 2024-08-08 11:33:49 --> Severity: Notice --> Undefined property: stdClass::$libur C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:33:49 --> Severity: Notice --> Undefined property: stdClass::$kbm_jam_mulai C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:33:49 --> Severity: Notice --> Undefined property: stdClass::$kbm_jam_pel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:33:49 --> Severity: Notice --> Undefined property: stdClass::$kbm_jml_mapel_hari C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:33:49 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:34:33 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 357
ERROR - 2024-08-08 11:34:33 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:34:33 --> Severity: Notice --> Undefined variable: times C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 118
ERROR - 2024-08-08 11:34:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 118
ERROR - 2024-08-08 11:34:33 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:34:33 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:34:33 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:34:33 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:34:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:34:48 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 78
ERROR - 2024-08-08 11:34:48 --> Severity: Warning --> Creating default object from empty value C:\laragon\www\ambk\application\controllers\Elearning.php 79
ERROR - 2024-08-08 11:34:48 --> Severity: Notice --> Undefined property: stdClass::$libur C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:34:48 --> Severity: Notice --> Undefined property: stdClass::$kbm_jam_mulai C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:34:48 --> Severity: Notice --> Undefined property: stdClass::$kbm_jam_pel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:34:48 --> Severity: Notice --> Undefined property: stdClass::$kbm_jml_mapel_hari C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:34:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:37:12 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 79
ERROR - 2024-08-08 11:37:12 --> Severity: Warning --> Creating default object from empty value C:\laragon\www\ambk\application\controllers\Elearning.php 80
ERROR - 2024-08-08 11:37:12 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:37:12 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:37:12 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:37:12 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:37:12 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:37:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:37:57 --> Severity: Notice --> Undefined variable: setting_kbm C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:37:57 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:37:57 --> Severity: Notice --> Undefined variable: setting_kbm C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 69
ERROR - 2024-08-08 11:37:57 --> Severity: Notice --> Undefined variable: setting_kbm C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:37:57 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:37:57 --> Severity: Notice --> Undefined variable: setting_kbm C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:37:57 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:37:57 --> Severity: Notice --> Undefined variable: setting_kbm C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:37:57 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:37:57 --> Severity: Notice --> Undefined variable: setting_kbm C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:37:57 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:37:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:38:12 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:38:12 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:38:12 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:38:12 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:38:12 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:38:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:39:54 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:39:54 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:39:54 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:39:54 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:39:54 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:39:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:39:55 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:39:55 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:39:55 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:39:55 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:39:55 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:39:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:40:12 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:40:12 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:40:12 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:40:12 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:40:12 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:40:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:40:21 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:40:21 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:40:21 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:40:21 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:40:21 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:40:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:42:31 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:42:31 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:42:31 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:42:31 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:42:31 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:42:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:42:33 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:42:33 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:42:33 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:42:33 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:42:33 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:42:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:43:08 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:43:08 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:43:08 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:43:08 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:43:08 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:43:08 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:44:22 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\controllers\Elearning.php 88
ERROR - 2024-08-08 11:44:22 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-08 11:44:22 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 603
ERROR - 2024-08-08 11:44:22 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 622
ERROR - 2024-08-08 11:44:22 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 632
ERROR - 2024-08-08 11:44:22 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:44:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:52:28 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\controllers\Elearning.php 368
ERROR - 2024-08-08 11:52:28 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 368
ERROR - 2024-08-08 11:52:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:55:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:55:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:56:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 11:59:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 12:02:05 --> Severity: Notice --> Undefined index: span C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 122
ERROR - 2024-08-08 12:02:05 --> Severity: Notice --> Undefined index: start C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 158
ERROR - 2024-08-08 12:02:05 --> Severity: Notice --> Undefined index: start C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 158
ERROR - 2024-08-08 12:02:05 --> Severity: Notice --> Undefined index: start C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 158
ERROR - 2024-08-08 12:02:05 --> Severity: Notice --> Undefined index: start C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 158
ERROR - 2024-08-08 12:02:05 --> Severity: Notice --> Undefined index: start C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 158
ERROR - 2024-08-08 12:02:05 --> Severity: Notice --> Undefined index: start C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 135
ERROR - 2024-08-08 12:02:05 --> Severity: Notice --> Undefined offset: 1 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 138
ERROR - 2024-08-08 12:02:05 --> Severity: Notice --> Undefined index: start C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 140
ERROR - 2024-08-08 12:02:05 --> Severity: Notice --> Undefined index: start C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 135
ERROR - 2024-08-08 12:02:05 --> Severity: Notice --> Undefined offset: 1 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 138
ERROR - 2024-08-08 12:02:05 --> Severity: Notice --> Undefined index: start C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 140
ERROR - 2024-08-08 12:02:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 12:09:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 12:09:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 14:08:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 14:10:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 14:11:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 14:13:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 14:17:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 653
ERROR - 2024-08-08 14:19:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 653
ERROR - 2024-08-08 14:21:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 14:24:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 14:25:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 14:25:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 650
ERROR - 2024-08-08 14:28:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 650
ERROR - 2024-08-08 14:30:43 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 651
ERROR - 2024-08-08 14:32:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Notice --> Trying to get property 'detail' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:32:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 652
ERROR - 2024-08-08 14:33:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 651
ERROR - 2024-08-08 14:33:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 651
ERROR - 2024-08-08 14:33:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 651
ERROR - 2024-08-08 14:34:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 651
ERROR - 2024-08-08 14:35:27 --> Severity: Notice --> Trying to get property '166' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 69
ERROR - 2024-08-08 14:35:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 651
ERROR - 2024-08-08 14:35:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 651
ERROR - 2024-08-08 14:36:20 --> Severity: Warning --> array_column() expects parameter 1 to be array, object given C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 156
ERROR - 2024-08-08 14:36:20 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 156
ERROR - 2024-08-08 14:36:20 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 157
ERROR - 2024-08-08 14:37:19 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 157
ERROR - 2024-08-08 14:38:22 --> Severity: Warning --> array_column() expects parameter 1 to be array, object given C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:38:22 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 160
ERROR - 2024-08-08 14:38:22 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 161
ERROR - 2024-08-08 14:39:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 655
ERROR - 2024-08-08 14:39:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 655
ERROR - 2024-08-08 14:47:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 655
ERROR - 2024-08-08 14:48:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 655
ERROR - 2024-08-08 14:48:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 655
ERROR - 2024-08-08 14:49:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 655
ERROR - 2024-08-08 14:53:30 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 655
ERROR - 2024-08-08 14:56:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 655
ERROR - 2024-08-08 14:56:57 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 655
ERROR - 2024-08-08 14:57:34 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 655
ERROR - 2024-08-08 14:59:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 655
ERROR - 2024-08-08 14:59:40 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 655
ERROR - 2024-08-08 15:00:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 655
ERROR - 2024-08-08 16:05:04 --> Severity: Notice --> Undefined offset: 0 C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-08 16:05:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 655
ERROR - 2024-08-08 16:30:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 700
ERROR - 2024-08-08 16:31:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 837
ERROR - 2024-08-08 16:32:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 837
ERROR - 2024-08-08 16:33:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 839
ERROR - 2024-08-08 16:34:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 841
