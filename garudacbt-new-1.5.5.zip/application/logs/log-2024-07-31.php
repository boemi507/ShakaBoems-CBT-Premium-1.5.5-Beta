<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-07-31 12:28:04 --> Severity: Notice --> Undefined variable: siswas C:\laragon\www\ambk\application\views\kelas\materijadwal\data.php 378
ERROR - 2024-07-31 12:28:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\materijadwal\data.php 378
ERROR - 2024-07-31 12:28:05 --> Severity: Notice --> Undefined variable: siswas C:\laragon\www\ambk\application\views\kelas\materijadwal\data.php 378
ERROR - 2024-07-31 12:28:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\materijadwal\data.php 378
ERROR - 2024-07-31 12:29:02 --> Severity: Notice --> Undefined index: X HOTEL C:\laragon\www\ambk\application\controllers\Dataguru.php 611
ERROR - 2024-07-31 12:29:02 --> Severity: Notice --> Undefined index: XA MPLB C:\laragon\www\ambk\application\controllers\Dataguru.php 674
ERROR - 2024-07-31 12:29:02 --> Severity: Notice --> Undefined index: XA MPLB C:\laragon\www\ambk\application\controllers\Dataguru.php 674
ERROR - 2024-07-31 12:29:02 --> Severity: Notice --> Undefined index: XA MPLB C:\laragon\www\ambk\application\controllers\Dataguru.php 674
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:29:20 --> Severity: Notice --> Undefined variable: kelas C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 202
ERROR - 2024-07-31 12:29:23 --> Severity: Notice --> Undefined variable: kelas C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 202
ERROR - 2024-07-31 12:29:30 --> Severity: Notice --> Undefined variable: kelas C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 202
ERROR - 2024-07-31 12:30:36 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:30:36 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:30:36 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:30:36 --> Severity: Notice --> Undefined variable: kelas_selected C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 66
ERROR - 2024-07-31 12:30:36 --> Severity: Notice --> Undefined variable: kelas C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 202
ERROR - 2024-07-31 12:30:38 --> Severity: Notice --> Undefined variable: kelas C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 202
ERROR - 2024-07-31 12:30:44 --> Severity: Notice --> Undefined variable: kelas C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 202
ERROR - 2024-07-31 12:30:45 --> Severity: Notice --> Undefined variable: kelas C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 202
ERROR - 2024-07-31 12:30:50 --> Severity: Notice --> Undefined variable: kelas C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 202
ERROR - 2024-07-31 12:30:52 --> Severity: Notice --> Undefined variable: kelas C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 202
ERROR - 2024-07-31 12:31:02 --> Severity: Notice --> Undefined variable: kelas C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 202
ERROR - 2024-07-31 12:31:04 --> Severity: Notice --> Undefined variable: kelas C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 202
ERROR - 2024-07-31 12:31:08 --> Severity: Notice --> Undefined variable: kelas C:\laragon\www\ambk\application\views\master\kelas\naikkelas.php 202
ERROR - 2024-07-31 12:31:37 --> Query error: Column 'jurusan_id' cannot be null - Invalid query: INSERT INTO `master_kelas` (`nama_kelas`, `kode_kelas`, `jurusan_id`, `id_tp`, `id_smt`, `level_id`, `guru_id`, `siswa_id`, `jumlah_siswa`) VALUES ('VII A', 'VIIA', NULL, '5', '1', '7', '', '361', 'a:1:{i:0;a:1:{s:2:\"id\";s:3:\"361\";}}')
ERROR - 2024-07-31 13:46:36 --> Severity: Notice --> Undefined variable: siswas C:\laragon\www\ambk\application\views\kelas\materijadwal\data.php 378
ERROR - 2024-07-31 13:46:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\materijadwal\data.php 378
ERROR - 2024-07-31 13:46:37 --> Severity: Notice --> Undefined variable: siswas C:\laragon\www\ambk\application\views\kelas\materijadwal\data.php 378
ERROR - 2024-07-31 13:46:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\materijadwal\data.php 378
ERROR - 2024-07-31 13:46:55 --> Severity: Notice --> Undefined variable: siswas C:\laragon\www\ambk\application\views\kelas\materijadwal\data.php 378
ERROR - 2024-07-31 13:46:55 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\materijadwal\data.php 378
ERROR - 2024-07-31 13:47:11 --> Severity: Notice --> Undefined variable: siswas C:\laragon\www\ambk\application\views\kelas\materijadwal\data.php 378
ERROR - 2024-07-31 13:47:11 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\materijadwal\data.php 378
ERROR - 2024-07-31 13:50:36 --> Severity: Notice --> Undefined variable: siswas C:\laragon\www\ambk\application\views\kelas\materijadwal\data.php 378
ERROR - 2024-07-31 13:50:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\materijadwal\data.php 378
