<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-07-26 14:18:37 --> Severity: Notice --> Undefined property: Cbtactivate::$dropdown C:\laragon\www\ambk\application\controllers\Cbtactivate.php 47
ERROR - 2024-07-26 14:18:37 --> Severity: error --> Exception: Call to a member function getAllRuang() on null C:\laragon\www\ambk\application\controllers\Cbtactivate.php 47
ERROR - 2024-07-26 14:23:50 --> Severity: Notice --> Undefined property: Cbtactivate::$cbt C:\laragon\www\ambk\application\controllers\Cbtactivate.php 51
ERROR - 2024-07-26 14:23:50 --> Severity: error --> Exception: Call to a member function getJadwalKelas() on null C:\laragon\www\ambk\application\controllers\Cbtactivate.php 51
ERROR - 2024-07-26 14:25:17 --> Severity: Notice --> Undefined property: Cbtstatus::$cbt C:\laragon\www\ambk\application\controllers\Cbtstatus.php 328
ERROR - 2024-07-26 14:25:17 --> Severity: error --> Exception: Call to a member function getJadwalById() on null C:\laragon\www\ambk\application\controllers\Cbtstatus.php 328
ERROR - 2024-07-26 14:26:27 --> Severity: Notice --> Undefined property: Cbtstatus::$cbt C:\laragon\www\ambk\application\controllers\Cbtstatus.php 329
ERROR - 2024-07-26 14:26:27 --> Severity: error --> Exception: Call to a member function getJadwalById() on null C:\laragon\www\ambk\application\controllers\Cbtstatus.php 329
