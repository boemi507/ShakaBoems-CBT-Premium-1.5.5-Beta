<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-03 14:53:17 --> Query error: Duplicate column name 'libur' - Invalid query: ALTER TABLE `kelas_jadwal_kbm`
	ADD `detail` LONGTEXT,
	ADD libur INT NOT NULL DEFAULT 7
ERROR - 2024-08-03 14:56:06 --> Query error: Duplicate column name 'libur' - Invalid query: ALTER TABLE `kelas_jadwal_kbm`
	ADD `detail` LONGTEXT,
	ADD libur INT NOT NULL DEFAULT 7
ERROR - 2024-08-03 14:56:51 --> Query error: Duplicate column name 'libur' - Invalid query: ALTER TABLE `kelas_jadwal_kbm`
	ADD `detail` LONGTEXT,
	ADD libur INT NOT NULL DEFAULT 7
ERROR - 2024-08-03 15:05:24 --> Query error: Table 'elearning.detail' doesn't exist - Invalid query: ALTER TABLE `detail` DROP COLUMN `kelas_jadwal_kbm`
ERROR - 2024-08-03 15:10:21 --> Severity: Notice --> Trying to access array offset on value of type int C:\laragon\www\ambk\system\database\DB_driver.php 1413
ERROR - 2024-08-03 15:10:21 --> Severity: Notice --> Trying to access array offset on value of type int C:\laragon\www\ambk\system\database\DB_driver.php 1413
ERROR - 2024-08-03 15:10:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 4 - Invalid query: ALTER TABLE `kelas_jadwal_kbm`
	ADD `detail` LONGTEXT,
	ADD libur INT NOT NULL DEFAULT 7,
	ADD `1` 
ERROR - 2024-08-03 15:12:18 --> Query error: Duplicate column name 'libur' - Invalid query: ALTER TABLE `kelas_jadwal_kbm`
	ADD `detail` LONGTEXT,
	ADD libur INT NOT NULL DEFAULT 7
ERROR - 2024-08-03 15:19:19 --> Severity: Notice --> Undefined variable: test_mapels C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 66
ERROR - 2024-08-03 15:19:31 --> Severity: Notice --> Undefined variable: test_mapels C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 66
ERROR - 2024-08-03 15:19:33 --> Severity: Notice --> Undefined variable: test_mapels C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 66
ERROR - 2024-08-03 15:36:37 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\controllers\Elearning.php 119
ERROR - 2024-08-03 15:37:34 --> Severity: Notice --> Undefined variable: test_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 66
ERROR - 2024-08-03 15:37:36 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\controllers\Elearning.php 119
ERROR - 2024-08-03 15:38:46 --> Severity: Notice --> Undefined variable: test_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 66
ERROR - 2024-08-03 15:38:48 --> Severity: Notice --> Undefined variable: test_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 66
ERROR - 2024-08-03 15:39:22 --> Severity: Notice --> Undefined variable: test_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 66
ERROR - 2024-08-03 16:23:03 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\controllers\Elearning.php 179
ERROR - 2024-08-03 16:23:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\controllers\Elearning.php 179
ERROR - 2024-08-03 16:23:03 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\controllers\Elearning.php 179
ERROR - 2024-08-03 16:23:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\controllers\Elearning.php 179
ERROR - 2024-08-03 16:23:03 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\controllers\Elearning.php 179
ERROR - 2024-08-03 16:23:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\controllers\Elearning.php 179
ERROR - 2024-08-03 16:23:03 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\controllers\Elearning.php 179
ERROR - 2024-08-03 16:23:03 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\controllers\Elearning.php 179
ERROR - 2024-08-03 16:23:03 --> Severity: Notice --> Undefined variable: mapels C:\laragon\www\ambk\application\controllers\Elearning.php 237
ERROR - 2024-08-03 16:23:04 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:04 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:04 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:04 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:04 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:28 --> Severity: Notice --> Undefined variable: mapels C:\laragon\www\ambk\application\controllers\Elearning.php 237
ERROR - 2024-08-03 16:23:28 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:28 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:28 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:28 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:28 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:46 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:46 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:46 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:46 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:23:46 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:25:41 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:25:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:25:41 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:25:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:25:41 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:25:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:25:41 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:25:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:27:01 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:27:01 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:27:01 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:27:01 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:27:01 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:27:05 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:27:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:27:05 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:27:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:27:05 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:27:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:27:05 --> Severity: Notice --> Undefined index: jadwal C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
ERROR - 2024-08-03 16:27:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 71
