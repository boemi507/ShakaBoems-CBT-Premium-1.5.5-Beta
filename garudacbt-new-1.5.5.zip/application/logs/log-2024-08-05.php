<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-05 14:19:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 265
ERROR - 2024-08-05 14:19:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 265
ERROR - 2024-08-05 14:21:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 265
ERROR - 2024-08-05 14:21:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 265
ERROR - 2024-08-05 14:27:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 265
ERROR - 2024-08-05 14:54:30 --> Severity: Notice --> Undefined variable: rows C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 130
ERROR - 2024-08-05 14:54:37 --> Severity: Notice --> Undefined variable: rows C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 130
ERROR - 2024-08-05 14:54:39 --> Severity: Notice --> Undefined variable: rows C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 130
ERROR - 2024-08-05 14:54:40 --> Severity: Notice --> Undefined variable: rows C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 130
ERROR - 2024-08-05 14:54:59 --> Severity: Notice --> Undefined variable: rows C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 130
ERROR - 2024-08-05 14:55:01 --> Severity: Notice --> Undefined variable: rows C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 130
ERROR - 2024-08-05 14:55:03 --> Severity: Notice --> Undefined variable: rows C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 130
ERROR - 2024-08-05 14:59:07 --> Severity: Notice --> Undefined variable: rows C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 130
ERROR - 2024-08-05 14:59:10 --> Severity: Notice --> Undefined variable: rows C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 130
