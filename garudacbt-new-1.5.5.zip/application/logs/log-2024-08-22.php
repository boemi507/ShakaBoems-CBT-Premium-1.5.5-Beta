<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-22 11:44:39 --> Query error: Duplicate column name 'libur' - Invalid query: ALTER TABLE `kelas_jadwal_kbm`
	ADD `kbm_jam_selesai` VARCHAR(5) AFTER `kbm_jam_mulai`,
	ADD libur INT NOT NULL DEFAULT 0
ERROR - 2024-08-22 12:00:14 --> Query error: Duplicate column name 'libur' - Invalid query: ALTER TABLE `kelas_jadwal_kbm`
	ADD `kbm_jam_selesai` VARCHAR(5) AFTER `kbm_jam_mulai`,
	ADD libur INT NOT NULL DEFAULT 0
ERROR - 2024-08-22 12:01:18 --> Query error: Duplicate column name 'libur' - Invalid query: ALTER TABLE `kelas_jadwal_kbm`
	ADD `kbm_jam_selesai` VARCHAR(5) AFTER `kbm_jam_mulai`,
	ADD libur INT NOT NULL DEFAULT 0
ERROR - 2024-08-22 12:13:14 --> Severity: Notice --> Undefined property: stdClass::$dari C:\laragon\www\ambk\application\controllers\Elearning.php 140
ERROR - 2024-08-22 12:14:06 --> Severity: Notice --> Undefined property: stdClass::$dari C:\laragon\www\ambk\application\controllers\Elearning.php 140
ERROR - 2024-08-22 12:22:10 --> Severity: Notice --> Undefined index: convert C:\laragon\www\ambk\application\views\elearning\jadwalkelas.php 38
