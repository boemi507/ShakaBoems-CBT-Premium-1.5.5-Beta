<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-21 10:04:49 --> Severity: error --> Exception: syntax error, unexpected ';', expecting ')' C:\laragon\www\ambk\application\controllers\Elearning.php 1355
ERROR - 2024-08-21 10:30:04 --> Severity: Notice --> Undefined variable: bulan C:\laragon\www\ambk\application\views\elearning\siswa_bulanan.php 79
ERROR - 2024-08-21 10:31:30 --> Severity: Notice --> Undefined property: Elearning::$dropdown C:\laragon\www\ambk\application\controllers\Elearning.php 1375
ERROR - 2024-08-21 10:31:30 --> Severity: error --> Exception: Call to a member function getBulan() on null C:\laragon\www\ambk\application\controllers\Elearning.php 1375
ERROR - 2024-08-21 10:32:12 --> Severity: error --> Exception: Call to undefined method Elearning_model::getBulan() C:\laragon\www\ambk\application\controllers\Elearning.php 1386
ERROR - 2024-08-21 10:35:14 --> Severity: Notice --> Undefined property: stdClass::$jam_ke C:\laragon\www\ambk\application\controllers\Elearning.php 1491
ERROR - 2024-08-21 10:35:14 --> Severity: Notice --> Undefined property: stdClass::$jam_ke C:\laragon\www\ambk\application\controllers\Elearning.php 1491
ERROR - 2024-08-21 10:35:14 --> Severity: Notice --> Undefined property: stdClass::$jam_ke C:\laragon\www\ambk\application\controllers\Elearning.php 1491
ERROR - 2024-08-21 10:35:14 --> Severity: Notice --> Undefined property: stdClass::$jam_ke C:\laragon\www\ambk\application\controllers\Elearning.php 1491
ERROR - 2024-08-21 10:35:14 --> Severity: Notice --> Undefined property: stdClass::$jam_ke C:\laragon\www\ambk\application\controllers\Elearning.php 1491
ERROR - 2024-08-21 10:35:14 --> Severity: Notice --> Undefined property: stdClass::$jam_ke C:\laragon\www\ambk\application\controllers\Elearning.php 1491
ERROR - 2024-08-21 10:35:14 --> Severity: Notice --> Undefined property: stdClass::$jam_ke C:\laragon\www\ambk\application\controllers\Elearning.php 1491
ERROR - 2024-08-21 10:35:14 --> Severity: Notice --> Undefined property: stdClass::$jam_ke C:\laragon\www\ambk\application\controllers\Elearning.php 1491
ERROR - 2024-08-21 10:53:52 --> Severity: Notice --> Undefined variable: info C:\laragon\www\ambk\application\views\elearning\siswa_harian.php 94
ERROR - 2024-08-21 10:56:35 --> Severity: Notice --> Undefined property: stdClass::$id_hari C:\laragon\www\ambk\application\controllers\Elearning.php 1267
ERROR - 2024-08-21 10:56:35 --> Severity: Notice --> Undefined property: stdClass::$id_hari C:\laragon\www\ambk\application\controllers\Elearning.php 1267
ERROR - 2024-08-21 10:56:35 --> Severity: Notice --> Undefined property: stdClass::$id_hari C:\laragon\www\ambk\application\controllers\Elearning.php 1267
ERROR - 2024-08-21 11:01:42 --> Severity: Notice --> Undefined variable: jadwal C:\laragon\www\ambk\application\views\elearning\siswa_harian.php 94
