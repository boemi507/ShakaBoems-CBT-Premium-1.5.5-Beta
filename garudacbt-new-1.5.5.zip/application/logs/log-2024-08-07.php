<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-07 11:06:08 --> Severity: Notice --> Undefined variable: jadwal_test C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 62
ERROR - 2024-08-07 11:10:05 --> Severity: Notice --> Undefined variable: arr_id_hari C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 45
ERROR - 2024-08-07 11:10:05 --> Severity: Warning --> array_slice() expects parameter 1 to be array, null given C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 45
ERROR - 2024-08-07 11:10:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 45
ERROR - 2024-08-07 11:10:05 --> Severity: Notice --> Undefined variable: arr_id_hari C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 48
ERROR - 2024-08-07 11:10:05 --> Severity: Warning --> array_slice() expects parameter 1 to be array, null given C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 48
ERROR - 2024-08-07 11:10:05 --> Severity: Warning --> Invalid argument supplied for foreach() C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 48
ERROR - 2024-08-07 11:23:47 --> Query error: Unknown column 'Senin' in 'where clause' - Invalid query: SELECT *
FROM `kelas_jadwal_mapel` `a`
LEFT JOIN `master_mapel` `b` ON `a`.`id_mapel`=`b`.`id_mapel`
WHERE id_tp =  5
AND id_smt =  1
AND id_hari =  Senin
ERROR - 2024-08-07 11:23:53 --> Query error: Unknown column 'Selasa' in 'where clause' - Invalid query: SELECT *
FROM `kelas_jadwal_mapel` `a`
LEFT JOIN `master_mapel` `b` ON `a`.`id_mapel`=`b`.`id_mapel`
WHERE id_tp =  5
AND id_smt =  1
AND id_hari =  Selasa
ERROR - 2024-08-07 11:23:59 --> Query error: Unknown column 'Senin' in 'where clause' - Invalid query: SELECT *
FROM `kelas_jadwal_mapel` `a`
LEFT JOIN `master_mapel` `b` ON `a`.`id_mapel`=`b`.`id_mapel`
WHERE id_tp =  5
AND id_smt =  1
AND id_hari =  Senin
ERROR - 2024-08-07 11:25:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:26:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:28:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:28:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:30:26 --> Severity: Warning --> json_encode() expects at least 1 parameter, 0 given C:\laragon\www\ambk\application\controllers\Elearning.php 473
ERROR - 2024-08-07 11:30:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:31:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:32:38 --> Severity: error --> Exception: syntax error, unexpected 'json_decode' (T_STRING) C:\laragon\www\ambk\application\controllers\Elearning.php 473
ERROR - 2024-08-07 11:36:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:36:39 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-07 11:36:39 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 157
ERROR - 2024-08-07 11:36:39 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 176
ERROR - 2024-08-07 11:36:39 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 186
ERROR - 2024-08-07 11:36:39 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:36:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:37:17 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-07 11:37:17 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 157
ERROR - 2024-08-07 11:37:17 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 176
ERROR - 2024-08-07 11:37:17 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 186
ERROR - 2024-08-07 11:37:17 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:37:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:37:50 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-07 11:37:50 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 157
ERROR - 2024-08-07 11:37:50 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 176
ERROR - 2024-08-07 11:37:50 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 186
ERROR - 2024-08-07 11:37:50 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:37:50 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:38:54 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-07 11:38:54 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 157
ERROR - 2024-08-07 11:38:54 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 176
ERROR - 2024-08-07 11:38:54 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 186
ERROR - 2024-08-07 11:38:54 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:38:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:38:58 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-07 11:38:58 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 157
ERROR - 2024-08-07 11:38:58 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 176
ERROR - 2024-08-07 11:38:58 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 186
ERROR - 2024-08-07 11:38:58 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:38:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:39:41 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 157
ERROR - 2024-08-07 11:39:41 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 176
ERROR - 2024-08-07 11:39:41 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 186
ERROR - 2024-08-07 11:39:41 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:39:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:39:43 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-07 11:39:58 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 157
ERROR - 2024-08-07 11:39:58 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 176
ERROR - 2024-08-07 11:39:58 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 186
ERROR - 2024-08-07 11:39:58 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:39:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:39:59 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-07 11:40:13 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 157
ERROR - 2024-08-07 11:40:13 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 176
ERROR - 2024-08-07 11:40:13 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 186
ERROR - 2024-08-07 11:40:13 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:40:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:41:44 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-07 11:41:44 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 157
ERROR - 2024-08-07 11:41:44 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 176
ERROR - 2024-08-07 11:41:44 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 186
ERROR - 2024-08-07 11:41:44 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:41:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:42:28 --> Severity: Notice --> Trying to get property 'libur' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 44
ERROR - 2024-08-07 11:42:28 --> Severity: Notice --> Trying to get property 'kbm_jam_mulai' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 157
ERROR - 2024-08-07 11:42:28 --> Severity: Notice --> Trying to get property 'kbm_jam_pel' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 176
ERROR - 2024-08-07 11:42:28 --> Severity: Notice --> Trying to get property 'kbm_jml_mapel_hari' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 186
ERROR - 2024-08-07 11:42:28 --> Severity: Notice --> Trying to get property 'istirahat' of non-object C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:42:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:43:20 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:43:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:43:23 --> Severity: Notice --> Undefined variable: id_kelas C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 82
ERROR - 2024-08-07 11:43:23 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 82
ERROR - 2024-08-07 11:43:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:43:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:48:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:49:03 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:49:05 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:49:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:49:36 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:49:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:49:51 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:50:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:50:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:50:25 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:50:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:50:28 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:50:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:51:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:51:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:51:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:53:19 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:53:21 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:53:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:56:24 --> Severity: error --> Exception: Too few arguments to function Elearning::hari(), 0 passed in C:\laragon\www\ambk\system\core\CodeIgniter.php on line 533 and exactly 1 expected C:\laragon\www\ambk\application\controllers\Elearning.php 321
ERROR - 2024-08-07 11:57:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:57:24 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:57:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:58:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:59:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:59:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:59:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:59:18 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:59:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 11:59:39 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 12:00:09 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 12:00:11 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 12:00:12 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 12:00:13 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 12:00:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 12:00:16 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 12:00:17 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 12:00:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 12:01:14 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 12:03:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 12:04:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 12:05:22 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 12:05:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 12:06:29 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 12:07:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 12:08:54 --> Severity: Notice --> Undefined variable: istirahat C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 69
ERROR - 2024-08-07 12:08:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 206
ERROR - 2024-08-07 12:09:18 --> Severity: Notice --> Undefined variable: istirahat C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 69
ERROR - 2024-08-07 13:07:53 --> Severity: Warning --> strpos() expects parameter 1 to be string, array given C:\laragon\www\ambk\application\controllers\Elearning.php 478
ERROR - 2024-08-07 13:07:53 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\laragon\www\ambk\application\controllers\Elearning.php 478
ERROR - 2024-08-07 13:07:53 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 232
ERROR - 2024-08-07 13:08:54 --> Severity: Warning --> strpos() expects parameter 1 to be string, array given C:\laragon\www\ambk\application\controllers\Elearning.php 79
ERROR - 2024-08-07 13:08:54 --> Severity: Warning --> json_decode() expects parameter 1 to be string, array given C:\laragon\www\ambk\application\controllers\Elearning.php 79
ERROR - 2024-08-07 13:08:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 232
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:44 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 438
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 439
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 440
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Undefined index:  C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to access array offset on value of type null C:\laragon\www\ambk\application\controllers\Elearning.php 441
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_kelas' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 442
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_hari' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 443
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'jam_ke' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 444
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'id_mapel' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 445
ERROR - 2024-08-07 13:18:45 --> Severity: Notice --> Trying to get property 'kode' of non-object C:\laragon\www\ambk\application\controllers\Elearning.php 446
ERROR - 2024-08-07 13:18:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 232
ERROR - 2024-08-07 13:21:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 232
ERROR - 2024-08-07 13:30:06 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 232
ERROR - 2024-08-07 13:30:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 232
ERROR - 2024-08-07 15:27:50 --> Severity: Notice --> Undefined variable: jadwal_mapel C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 71
ERROR - 2024-08-07 15:28:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 232
ERROR - 2024-08-07 15:29:04 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 232
ERROR - 2024-08-07 15:29:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 232
ERROR - 2024-08-07 15:37:43 --> Severity: Warning --> Illegal offset type C:\laragon\www\ambk\application\controllers\Elearning.php 432
ERROR - 2024-08-07 15:37:43 --> Severity: Warning --> Illegal offset type C:\laragon\www\ambk\application\controllers\Elearning.php 432
ERROR - 2024-08-07 15:37:43 --> Severity: Warning --> Illegal offset type C:\laragon\www\ambk\application\controllers\Elearning.php 432
ERROR - 2024-08-07 15:39:23 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 232
ERROR - 2024-08-07 15:41:36 --> Severity: error --> Exception: syntax error, unexpected ';' C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 118
ERROR - 2024-08-07 15:42:09 --> Severity: error --> Exception: syntax error, unexpected ';' C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 118
ERROR - 2024-08-07 15:42:10 --> Severity: error --> Exception: syntax error, unexpected ';' C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 118
ERROR - 2024-08-07 15:42:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 303
ERROR - 2024-08-07 15:42:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 303
ERROR - 2024-08-07 15:42:42 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 303
ERROR - 2024-08-07 15:44:27 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 303
ERROR - 2024-08-07 15:45:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 303
ERROR - 2024-08-07 15:45:41 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 303
ERROR - 2024-08-07 15:48:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 304
ERROR - 2024-08-07 15:50:15 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwalkelas.php 304
