<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-20 13:21:12 --> Severity: Warning --> Attempt to read property "title" on array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 416
ERROR - 2024-05-20 13:21:12 --> Severity: Warning --> Attempt to read property "title" on array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 479
ERROR - 2024-05-20 13:21:12 --> Severity: Warning --> Attempt to read property "title" on array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 479
ERROR - 2024-05-20 13:21:15 --> Severity: Warning --> Attempt to read property "title" on array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 416
ERROR - 2024-05-20 13:21:15 --> Severity: Warning --> Attempt to read property "title" on array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 479
ERROR - 2024-05-20 13:21:15 --> Severity: Warning --> Attempt to read property "title" on array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 479
ERROR - 2024-05-20 13:21:24 --> Severity: Warning --> Attempt to read property "title" on array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 416
ERROR - 2024-05-20 13:21:24 --> Severity: Warning --> Attempt to read property "title" on array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 479
ERROR - 2024-05-20 13:21:24 --> Severity: Warning --> Attempt to read property "title" on array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 479
ERROR - 2024-05-20 13:21:29 --> Severity: Warning --> Attempt to read property "title" on array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 416
ERROR - 2024-05-20 13:21:29 --> Severity: Warning --> Attempt to read property "title" on array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 479
ERROR - 2024-05-20 13:21:29 --> Severity: Warning --> Attempt to read property "title" on array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 479
ERROR - 2024-05-20 13:22:41 --> Severity: Warning --> Attempt to read property "title" on array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 479
ERROR - 2024-05-20 13:22:41 --> Severity: Warning --> Attempt to read property "title" on array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 479
