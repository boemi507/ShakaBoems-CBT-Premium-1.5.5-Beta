<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-05-22 09:40:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 41
ERROR - 2024-05-22 09:40:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 41
ERROR - 2024-05-22 09:40:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 54
ERROR - 2024-05-22 09:40:31 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 73
ERROR - 2024-05-22 09:41:38 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 58
ERROR - 2024-05-22 09:43:11 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 58
ERROR - 2024-05-22 09:56:23 --> Severity: Warning --> Attempt to read property "jawaban_siswa" on array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 741
ERROR - 2024-05-22 09:56:23 --> Severity: Warning --> Attempt to read property "links" on null C:\laragon\www\ambk\application\controllers\Cbtnilai.php 741
ERROR - 2024-05-22 09:56:23 --> Severity: error --> Exception: Cbtnilai::sortArrays(): Argument #1 ($array) cannot be passed by reference C:\laragon\www\ambk\application\controllers\Cbtnilai.php 741
ERROR - 2024-05-22 09:57:25 --> Severity: Warning --> Undefined variable $array1 C:\laragon\www\ambk\application\controllers\Cbtnilai.php 750
ERROR - 2024-05-22 09:57:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 750
ERROR - 2024-05-22 09:57:25 --> Severity: Warning --> Undefined variable $array2 C:\laragon\www\ambk\application\controllers\Cbtnilai.php 769
ERROR - 2024-05-22 09:57:25 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 769
ERROR - 2024-05-22 09:57:25 --> Severity: Warning --> Undefined property: stdClass::$tabel_soal C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 444
ERROR - 2024-05-22 09:57:25 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 444
ERROR - 2024-05-22 09:57:50 --> Severity: Warning --> Undefined property: stdClass::$tabel_soal C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 444
ERROR - 2024-05-22 09:57:50 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 444
ERROR - 2024-05-22 09:58:18 --> Severity: Warning --> Undefined property: stdClass::$tabel_soal C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 388
ERROR - 2024-05-22 09:58:18 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 388
ERROR - 2024-05-22 10:02:18 --> Severity: Warning --> Undefined variable $sameCount C:\laragon\www\ambk\application\controllers\Cbtnilai.php 1028
ERROR - 2024-05-22 10:02:18 --> Severity: Warning --> Undefined variable $differentCount C:\laragon\www\ambk\application\controllers\Cbtnilai.php 1029
ERROR - 2024-05-22 10:42:17 --> Severity: Warning --> Attempt to read property "jawaban_siswa" on array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 748
ERROR - 2024-05-22 10:42:17 --> Severity: Warning --> Attempt to read property "links" on null C:\laragon\www\ambk\application\controllers\Cbtnilai.php 748
ERROR - 2024-05-22 10:42:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 540
ERROR - 2024-05-22 10:42:17 --> Severity: Warning --> Attempt to read property "jawaban_benar" on array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 750
ERROR - 2024-05-22 10:42:17 --> Severity: Warning --> Attempt to read property "links" on null C:\laragon\www\ambk\application\controllers\Cbtnilai.php 750
ERROR - 2024-05-22 10:42:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 540
ERROR - 2024-05-22 10:42:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 757
ERROR - 2024-05-22 10:42:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 776
ERROR - 2024-05-22 10:42:17 --> Severity: Warning --> Attempt to read property "jawaban_siswa" on array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 748
ERROR - 2024-05-22 10:42:17 --> Severity: Warning --> Attempt to read property "links" on null C:\laragon\www\ambk\application\controllers\Cbtnilai.php 748
ERROR - 2024-05-22 10:42:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 540
ERROR - 2024-05-22 10:42:17 --> Severity: Warning --> Attempt to read property "jawaban_benar" on array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 750
ERROR - 2024-05-22 10:42:17 --> Severity: Warning --> Attempt to read property "links" on null C:\laragon\www\ambk\application\controllers\Cbtnilai.php 750
ERROR - 2024-05-22 10:42:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 540
ERROR - 2024-05-22 10:42:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 757
ERROR - 2024-05-22 10:42:17 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 776
ERROR - 2024-05-22 10:44:53 --> Severity: Warning --> Attempt to read property "jawaban_siswa" on array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 748
ERROR - 2024-05-22 10:44:53 --> Severity: Warning --> Attempt to read property "links" on null C:\laragon\www\ambk\application\controllers\Cbtnilai.php 748
ERROR - 2024-05-22 10:44:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 540
ERROR - 2024-05-22 10:44:53 --> Severity: Warning --> Attempt to read property "jawaban_benar" on array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 750
ERROR - 2024-05-22 10:44:53 --> Severity: Warning --> Attempt to read property "links" on null C:\laragon\www\ambk\application\controllers\Cbtnilai.php 750
ERROR - 2024-05-22 10:44:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 540
ERROR - 2024-05-22 10:44:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 757
ERROR - 2024-05-22 10:44:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 776
ERROR - 2024-05-22 10:44:53 --> Severity: Warning --> Attempt to read property "jawaban_siswa" on array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 748
ERROR - 2024-05-22 10:44:53 --> Severity: Warning --> Attempt to read property "links" on null C:\laragon\www\ambk\application\controllers\Cbtnilai.php 748
ERROR - 2024-05-22 10:44:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 540
ERROR - 2024-05-22 10:44:53 --> Severity: Warning --> Attempt to read property "jawaban_benar" on array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 750
ERROR - 2024-05-22 10:44:53 --> Severity: Warning --> Attempt to read property "links" on null C:\laragon\www\ambk\application\controllers\Cbtnilai.php 750
ERROR - 2024-05-22 10:44:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 540
ERROR - 2024-05-22 10:44:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 757
ERROR - 2024-05-22 10:44:53 --> Severity: Warning --> foreach() argument must be of type array|object, null given C:\laragon\www\ambk\application\controllers\Cbtnilai.php 776
ERROR - 2024-05-22 10:44:53 --> Severity: Warning --> Undefined variable $jwbn_jodoh C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 40
ERROR - 2024-05-22 10:45:32 --> Severity: Warning --> Undefined variable $jwbn_jodoh C:\laragon\www\ambk\application\views\cbt\nilai\detail.php 40
ERROR - 2024-05-22 10:47:03 --> Severity: error --> Exception: syntax error, unexpected token "*" C:\laragon\www\ambk\application\controllers\Cbtnilai.php 789
ERROR - 2024-05-22 10:47:16 --> Severity: error --> Exception: Cannot use object of type stdClass as array C:\laragon\www\ambk\application\controllers\Cbtnilai.php 758
