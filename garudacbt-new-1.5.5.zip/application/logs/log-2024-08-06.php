<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-08-06 10:25:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 271
ERROR - 2024-08-06 10:32:37 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 161
ERROR - 2024-08-06 10:32:59 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 273
ERROR - 2024-08-06 10:33:59 --> Severity: Notice --> Undefined offset: 162 C:\laragon\www\ambk\application\views\kelas\jadwal\data.php 91
ERROR - 2024-08-06 10:34:52 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 273
ERROR - 2024-08-06 10:42:54 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 281
ERROR - 2024-08-06 10:42:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 281
ERROR - 2024-08-06 10:45:55 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 282
ERROR - 2024-08-06 10:52:35 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 282
ERROR - 2024-08-06 10:52:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 282
ERROR - 2024-08-06 10:52:38 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 282
ERROR - 2024-08-06 10:53:33 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 275
ERROR - 2024-08-06 10:55:26 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 273
ERROR - 2024-08-06 10:58:32 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 271
ERROR - 2024-08-06 10:58:37 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 271
ERROR - 2024-08-06 10:58:45 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 271
ERROR - 2024-08-06 11:00:48 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 271
ERROR - 2024-08-06 11:05:44 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 271
ERROR - 2024-08-06 11:57:00 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 195
ERROR - 2024-08-06 12:01:10 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\laragon\www\ambk\application\views\kelas\elearning\jadwal.php 249
