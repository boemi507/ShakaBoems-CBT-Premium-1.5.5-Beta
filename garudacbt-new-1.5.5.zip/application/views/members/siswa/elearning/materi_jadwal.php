<?php
/**
 * Created by IntelliJ IDEA.
 * User: multazam
 * Date: 07/08/20
 * Time: 22:29
 */
?>
<div class="content-wrapper" style="margin-top: -1px;">
    <div class="sticky">
    </div>
    <section class="content overlap">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <?php $this->load->view('members/siswa/templates/top'); ?>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card my-shadow">
                        <div class="card-header">
                            <h5 class="text-center">
                                <?= strtoupper($judul ?? '') ?> HARI INI<br/><?= buat_tanggal(date('D, d M Y')) ?>
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <?php if (count($jadwal_materi->detail) > 0) :
                                    ksort($jadwal_materi->detail);
                                    foreach ($jadwal_materi->detail as $mulai=>$jadwals) : ?>
                                <span><?= $mulai ?>, </span>
                                <?php endforeach; ?>
                                <?php else: ?>
                                <span>kosong</span>
                                <?php endif; ?>
                            </div>
                            <hr />
                            <pre>
                                <?php
                                //print_r($jadwal_materi);
                                ?>
                            </pre>
                        </div>
                    </div>
                </div>
                <div class="col-12">
                    <div class="card my-shadow">
                        <div class="card-header">
                            <h5 class="text-center">
                                <?= strtoupper($judul ?? '') ?> TERDAHULU
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="dates-wrapper">
                                <span class="scroll-button scroll-left" onclick="scrollKiri()">&#10094;</span>
                                <div id="dates" class="dates-container"></div>
                                <span class="scroll-button scroll-right" onclick="scrollKanan()">&#10095;</span>
                            </div>
                        </div>
                        <div class="overlay d-none" id="loading">
                            <div class="spinner-grow"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<script>
    $(document).ready(function () {
        //getMateri(senin);
        generateDates()
        var w = $(window).width();
        setWidth(w);

        $(window).on('resize', function () {
            setWidth($(this).width());
        });
    });

    function generateDates() {
        const datesContainer = document.getElementById('dates');
        const now = new Date();
        const year = now.getFullYear();
        const month = now.getMonth();

        // Mendapatkan jumlah hari dalam bulan ini
        const monthNames = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
        const dayNames = ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"];

        for (let i = -15; i <= 15; i++) {
            const date = new Date(now);
            date.setDate(now.getDate() + i);

            const dayName = dayNames[date.getDay()];
            const day = date.getDate();
            const monthName = monthNames[date.getMonth()];

            const dateBox = document.createElement('div');
            dateBox.className = 'mx-1 px-2 py-1 btn alert text-center';
            dateBox.innerHTML = `<b>${dayName}</b><br /><small>${day} ${monthName}</small>`;
            if (date.toDateString() === now.toDateString()) {
                dateBox.classList.add('alert-default-secondary');
                dateBox.classList.add('btn-disabled');
                dateBox.setAttribute('disabled', 'disabled')
            } else if (date.getDay() === 0) { // 0 = Minggu
                dateBox.classList.add('alert-default-danger');
            } else {
                dateBox.classList.add('alert-default-primary');
            }
            datesContainer.appendChild(dateBox);
        }
    }

    function setWidth(width) {
        let w;
        if (width <= 750) {
            w = '';
        } else if (width <= 975) {
            w = 300;
        } else if (width <= 1182) {
            w = 260;
        } else {
            w = 320;
        }
        $(".nama-mapel").css("width", w);
    }

    function showDialog(sel) {
        swal.fire({
            title: "HASIL <?= strtoupper($judul ?? '') ?>",
            html: '<table class="table table-striped table-bordered w-100">' +
                '    <tr>' +
                '        <th>NILAI</th>' +
                '        <th>Catatan Guru</th>' +
                '    </tr>' +
                '    <tr>' +
                '        <td class="text-lg text-bold">' + $(sel).data('nilai') + '</td>' +
                '        <td>' + $(sel).data('text') + '</td>' +
                '    </tr>' +
                '</table>',
            confirmButtonText: "TUTUP"
        })
    }

    function scrollKiri() {
        const datesContainer = document.getElementById('dates');
        datesContainer.scrollBy({ left: -150, behavior: 'smooth' });
    }

    function scrollKanan() {
        const datesContainer = document.getElementById('dates');
        datesContainer.scrollBy({ left: 150, behavior: 'smooth' });
    }
</script>
